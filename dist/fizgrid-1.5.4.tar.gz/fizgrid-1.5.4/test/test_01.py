try:
    import fizgrid

    print("test_01.py: passed")
except:
    print("test_01.py: failed")
